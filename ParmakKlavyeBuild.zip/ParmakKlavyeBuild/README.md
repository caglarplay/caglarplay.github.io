# Parmak Klavye v0.1

Android için Türkçe Q özel klavye (IME).

## Özellikler
- Türkçe Q: ğ, ü, ş, ı, ö, ç
- Sabit sayı satırı
- Büyük ve aralıklı tuşlar
- Shift, silme, Enter, boşluk
- Sembol ekranı
- Hafif dokunsal geri bildirim
- INTERNET izni yok

## Derleme
Android Studio Quail 4 / AGP 9.4.0 veya uyumlu sürümle açın.
Compile SDK / Target SDK: 36
Min SDK: 26
JDK: 17

## Kurulum
1. APK'yı kurun.
2. Parmak Klavye uygulamasını açın.
3. “Klavyeyi etkinleştir”e basın ve Parmak Klavye'yi açın.
4. “Klavyeyi seç”e basın ve Parmak Klavye'yi seçin.
