package com.alaa.parmakklavye;

import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.inputmethodservice.InputMethodService;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputConnection;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ParmakKeyboardService extends InputMethodService {

    private static final String BACKSPACE = "⌫";
    private static final String SHIFT = "⇧";
    private static final String ENTER = "↵";
    private static final String SPACE = "boşluk";
    private static final String SYMBOLS = "?123";
    private static final String LETTERS = "ABC";

    private final List<Button> letterButtons = new ArrayList<>();
    private boolean shift = false;
    private boolean symbols = false;
    private LinearLayout keyboardRoot;

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    public View onCreateInputView() {
        keyboardRoot = new LinearLayout(this);
        keyboardRoot.setOrientation(LinearLayout.VERTICAL);
        keyboardRoot.setPadding(dp(3), dp(5), dp(3), dp(7));
        keyboardRoot.setBackgroundColor(Color.rgb(226, 229, 234));
        rebuildKeyboard();
        return keyboardRoot;
    }

    private void rebuildKeyboard() {
        keyboardRoot.removeAllViews();
        letterButtons.clear();

        if (symbols) {
            addRow(new String[]{"1","2","3","4","5","6","7","8","9","0"}, 1f);
            addRow(new String[]{"@","#","₺","_","&","-","+","(", ")","/"}, 1f);
            addRow(new String[]{"*","\"","'",":",";","!","?","%","=",BACKSPACE}, 1f);
            addBottomRow();
        } else {
            addRow(new String[]{"1","2","3","4","5","6","7","8","9","0"}, 0.92f);
            addRow(new String[]{"q","w","e","r","t","y","u","ı","o","p","ğ","ü"}, 1f);
            addRow(new String[]{"a","s","d","f","g","h","j","k","l","ş","i"}, 1f);
            addRow(new String[]{SHIFT,"z","x","c","v","b","n","m","ö","ç",BACKSPACE}, 1f);
            addBottomRow();
        }
    }

    private void addRow(String[] keys, float textScale) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        row.setPadding(0, dp(2), 0, dp(2));

        for (String key : keys) {
            Button button = makeKey(key, textScale);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(50), weightFor(key));
            lp.setMargins(dp(2), 0, dp(2), 0);
            row.addView(button, lp);
            if (isLetterKey(key)) letterButtons.add(button);
        }

        keyboardRoot.addView(row, new LinearLayout.LayoutParams(-1, -2));
    }

    private void addBottomRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        row.setPadding(0, dp(2), 0, dp(2));

        String mode = symbols ? LETTERS : SYMBOLS;
        String[] keys = new String[]{mode, ",", SPACE, ".", ENTER};
        for (String key : keys) {
            Button b = makeKey(key, 1f);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(54), weightFor(key));
            lp.setMargins(dp(2), 0, dp(2), 0);
            row.addView(b, lp);
        }
        keyboardRoot.addView(row, new LinearLayout.LayoutParams(-1, -2));
    }

    private float weightFor(String key) {
        if (SPACE.equals(key)) return 4.4f;
        if (SHIFT.equals(key) || BACKSPACE.equals(key) || ENTER.equals(key)) return 1.45f;
        if (SYMBOLS.equals(key) || LETTERS.equals(key)) return 1.55f;
        return 1f;
    }

    private Button makeKey(String key, float textScale) {
        Button b = new Button(this);
        b.setText(displayText(key));
        b.setTextSize((symbols ? 18 : 19) * textScale);
        b.setTextColor(Color.rgb(22, 24, 27));
        b.setGravity(Gravity.CENTER);
        b.setAllCaps(false);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(0, 0, 0, 0);
        b.setTypeface(Typeface.create("sans", Typeface.NORMAL));
        b.setBackground(keyBackground(isSpecial(key)));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            b.setStateListAnimator(null);
        }
        b.setOnClickListener(v -> handleKey(key));
        return b;
    }

    private GradientDrawable keyBackground(boolean special) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(special ? Color.rgb(195, 200, 207) : Color.WHITE);
        bg.setCornerRadius(dp(7));
        return bg;
    }

    private boolean isSpecial(String key) {
        return SHIFT.equals(key) || BACKSPACE.equals(key) || ENTER.equals(key)
                || SPACE.equals(key) || SYMBOLS.equals(key) || LETTERS.equals(key);
    }

    private boolean isLetterKey(String key) {
        return key.length() == 1 && Character.isLetter(key.charAt(0));
    }

    private String displayText(String key) {
        if (isLetterKey(key) && shift) return key.toUpperCase(new Locale("tr", "TR"));
        return key;
    }

    private void handleKey(String key) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        vibrate();

        switch (key) {
            case BACKSPACE:
                CharSequence selected = ic.getSelectedText(0);
                if (selected != null && selected.length() > 0) {
                    ic.commitText("", 1);
                } else {
                    ic.deleteSurroundingText(1, 0);
                }
                break;
            case SHIFT:
                shift = !shift;
                refreshLetters();
                break;
            case ENTER:
                if (!ic.performEditorAction(getCurrentInputEditorInfo().imeOptions & 0xFF)) {
                    ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER));
                    ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER));
                }
                break;
            case SPACE:
                ic.commitText(" ", 1);
                break;
            case SYMBOLS:
            case LETTERS:
                symbols = !symbols;
                shift = false;
                rebuildKeyboard();
                break;
            default:
                String out = key;
                if (isLetterKey(key) && shift) {
                    out = key.toUpperCase(new Locale("tr", "TR"));
                    shift = false;
                    refreshLetters();
                }
                ic.commitText(out, 1);
                break;
        }
    }

    private void refreshLetters() {
        for (Button b : letterButtons) {
            String raw = b.getText().toString();
            String lower = raw.toLowerCase(new Locale("tr", "TR"));
            b.setText(shift ? lower.toUpperCase(new Locale("tr", "TR")) : lower);
        }
    }

    private void vibrate() {
        try {
            Vibrator vib = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (vib == null || !vib.hasVibrator()) return;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vib.vibrate(VibrationEffect.createOneShot(12, 35));
            } else {
                vib.vibrate(12);
            }
        } catch (Exception ignored) {
        }
    }
}
