package com.alaa.parmakklavye;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(24), dp(42), dp(24), dp(24));
        root.setBackgroundColor(Color.rgb(244, 245, 247));

        TextView title = new TextView(this);
        title.setText("Parmak Klavye");
        title.setTextSize(30);
        title.setTextColor(Color.rgb(23, 24, 26));
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, dp(12));
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView desc = new TextView(this);
        desc.setText("Büyük ve aralıklı Türkçe Q klavye. İnternet izni yok; yazdıkların cihazdan dışarı gönderilmez.");
        desc.setTextSize(16);
        desc.setTextColor(Color.rgb(95, 99, 104));
        desc.setGravity(Gravity.CENTER);
        desc.setLineSpacing(0, 1.15f);
        desc.setPadding(0, 0, 0, dp(28));
        root.addView(desc, new LinearLayout.LayoutParams(-1, -2));

        Button enable = actionButton("1. Klavyeyi etkinleştir");
        enable.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)));
        root.addView(enable, buttonLp());

        Button choose = actionButton("2. Klavyeyi seç");
        choose.setOnClickListener(v -> {
            android.view.inputmethod.InputMethodManager imm =
                    (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (imm != null) imm.showInputMethodPicker();
        });
        root.addView(choose, buttonLp());

        TextView hint = new TextView(this);
        hint.setText("Önce etkinleştir, sonra listeden “Parmak Klavye”yi seç. Ardından WhatsApp veya herhangi bir yazı alanında kullanabilirsin.");
        hint.setTextSize(14);
        hint.setTextColor(Color.rgb(95, 99, 104));
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(0, dp(20), 0, 0);
        root.addView(hint, new LinearLayout.LayoutParams(-1, -2));

        setContentView(root);
    }

    private LinearLayout.LayoutParams buttonLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(58));
        lp.setMargins(0, dp(8), 0, dp(8));
        return lp;
    }

    private Button actionButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(17);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(Color.rgb(37, 99, 235));
        return b;
    }
}
